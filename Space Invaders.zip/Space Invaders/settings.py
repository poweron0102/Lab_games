RES = (800, 600)
Width = RES[0]
HalfWidth = Width // 2
Height = RES[1]
HalfHeight = Height // 2

PlayerSpeed = 5
ArrowSpeed = -10

MaxArrows = 2
