# pplay
Framework para criação de jogos em Python utilizado pelos alunos de Ciência da Computação da Universidade Federal Fluminense.

Mais informações e documentação detalhada no site do projeto:
http://www2.ic.uff.br/pplay/
